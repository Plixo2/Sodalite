package org.libsdl;

import java.io.IOException;
import java.lang.foreign.Arena;
import java.lang.foreign.Linker;
import java.lang.foreign.SymbolLookup;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Objects;
import java.util.Optional;

/// Overwrite the default symbol lookup to load the dll
public class SDLLoad {
    private SDLLoad() {}

    private static final String CUSTOM_LIBRARY_PATH = System.getProperty("sodalite.library.path");
    private static final String DEFAULT_LIBRARY_PATH = "SDL3";


    public static SymbolLookup lookup(Arena arena) {
        try {
            return defaultLookup(arena)
                    .or(SymbolLookup.loaderLookup())
                    .or(Linker.nativeLinker().defaultLookup());

        } catch(Exception e) {
            if (CUSTOM_LIBRARY_PATH != null) {
                throw new SDLLoadException(
                        "Failed to load SDL from '" + CUSTOM_LIBRARY_PATH + "'",
                        e
                );
            }
            throw new SDLLoadException(
                    "Failed to load SDL. "
                    + "Use the 'sodalite.library.path' system property "
                    + "to specify a custom path to the dynamic library",
                    e
            );
        }
    }

    public static SymbolLookup lookupWithResource(Arena arena) {
        try {
            SymbolLookup lookup;
            if (CUSTOM_LIBRARY_PATH != null) {
                lookup = defaultLookup(arena);
            } else {
                var platform = getPlatform();
                lookup = switch (platform) {
                    case WIN_X86 -> windowsLookup("x86", arena);
                    case WIN_X64 -> windowsLookup("x64", arena);
                    case WIN_ARM64 -> windowsLookup("arm64", arena);
                    case OTHER -> defaultLookup(arena);
                };
            }

            return lookup
                    .or(SymbolLookup.loaderLookup())
                    .or(Linker.nativeLinker().defaultLookup());

        } catch(Exception e) {
            if (CUSTOM_LIBRARY_PATH != null) {
                throw new SDLLoadException(
                        "Failed to load SDL library from custom path: " + CUSTOM_LIBRARY_PATH,
                        e
                );
            }
            throw new SDLLoadException(
                    "Failed to load SDL library. "
                    + "Use the 'sodalite.library.path' system property "
                    + "to specify a custom path",
                    e
            );
        }
    }

    private static final String WIN_RESOURCE_PATH = "natives/win/$arch/SDL3.dll";

    private static SymbolLookup windowsLookup(
            String arch,
            Arena arena
    ) {
        var resourcePath = WIN_RESOURCE_PATH.replace("$arch", arch);
        var sym = loadWindowsDLL(resourcePath, arena);

        return sym.orElseGet(() -> defaultLookup(arena));
    }
    private static Path nativesDirectory() throws IOException {
        var dir = Path.of(".").toAbsolutePath().normalize();
        Files.createDirectories(dir);
        return dir;
    }

    private static Optional<SymbolLookup> loadWindowsDLL(
            String resource,
            Arena arena
    ) {
        var anchor = SDLLoad.class.getClassLoader();
        try (var in = anchor.getResourceAsStream(resource)) {
            if (in == null) {
                throw new IOException("Resource not found: " + resource);
            }

            var tmp = nativesDirectory().resolve("SDL3.dll");
            Files.copy(in, tmp, StandardCopyOption.REPLACE_EXISTING);

            return Optional.of(SymbolLookup.libraryLookup(tmp, arena));
        } catch (Exception e) {
            return Optional.empty();
        }
    }

    private static SymbolLookup defaultLookup(Arena arena) {
        var path = Objects.requireNonNullElse(CUSTOM_LIBRARY_PATH, DEFAULT_LIBRARY_PATH);
        return SymbolLookup.libraryLookup(path, arena);
    }

    private static Platform getPlatform() {
        String os = System.getProperty("os.name", "").toLowerCase();
        String arch = System.getProperty("os.arch", "").toLowerCase();

        if (os.contains("win")) {
            if (arch.contains("arm64") || arch.contains("aarch64")) {
                return Platform.WIN_ARM64;
            } else if (arch.contains("64")) {
                return Platform.WIN_X64;
            } else {
                return Platform.WIN_X86;
            }
        }

        return Platform.OTHER;
    }

    private enum Platform {
        WIN_X86,
        WIN_X64,
        WIN_ARM64,
        OTHER,

        ;
    }
    public final static class SDLLoadException extends RuntimeException {
        public SDLLoadException(String message, Throwable cause) {
            super(message, cause);
        }
    }

}
